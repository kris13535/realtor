const loading_array=[
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
    {loading_img:  "/coming_soon.jpg"},
];

export {loading_array};